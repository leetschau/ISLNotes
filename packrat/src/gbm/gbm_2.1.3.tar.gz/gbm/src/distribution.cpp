//  GBM by Greg Ridgeway  Copyright (C) 2003

#include "distribution.h"

CDistribution::CDistribution()
{

}

CDistribution::~CDistribution()
{
}




